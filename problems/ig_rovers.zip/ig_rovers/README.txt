The file ig_rovers.dpomdp contains the description of the information gathering rovers planning domain introduced in the paper:

Mikko Lauri, Joni Pajarinen, Jan Peters. "Information gathering in decentralized POMDPs by policy graph improvement", in 18th International Conference on Autonomous Agents and Multiagent Systems (AAMAS), 2019

** Due to the limitations of the .dpomdp format, the negative entropy reward mentioned in the paper is not visible in the file! Users should take care to include it themselves.

For more information on the .dpomdp format, see:
http://masplan.org/problem_domains
https://github.com/MADPToolbox/MADP
