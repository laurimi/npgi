The file mav.dpomdp contains the description of the MAV planning domain introduced in the paper:

Mikko Lauri, Eero Heinänen, Simone Frintrop. "Multi-robot active information gathering with periodic communication", in IEEE International Conference on Robotics and Automation (ICRA), 2017, pp. 851-856.


This version starts from a uniform belief on the location and status of the target.

** Due to the limitations of the .dpomdp format, the negative entropy reward mentioned in the paper is not visible in the file! Users should take care to include it themselves.

For more information on the .dpomdp format, see:
http://masplan.org/problem_domains
https://github.com/MADPToolbox/MADP
